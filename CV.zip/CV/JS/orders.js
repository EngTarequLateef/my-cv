var btnScrl = document.getElementById('btn-Scrll'),
    nvTop = document.getElementById('top-Nav');

window.onscroll = function() {

    if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
        btnScrl.style.display = "block";
        // nvTop.style.position = 'fixed';
        btnScrl.style.zIndex = '99';
    } else {
        btnScrl.style.display = 'none';
        // nvTop.style.position = 'relative';
        btnScrl.style.zIndex = '0';
    }
}

function scrllUp() {
    document.body.scrolltop = 0;
    document.documentElement.scrollTop = 0;
}